
def tutorial = ec.entity.makeValue("tutorial.Tutorial")
tutorial.setAll(context)
if (!tutorial.tutorialId) tutorial.setSequencedIdPrimary()
tutorial.create()
